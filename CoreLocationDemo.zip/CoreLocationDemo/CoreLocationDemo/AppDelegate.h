//
//  AppDelegate.h
//  CoreLocationDemo
//
//  Created by nus on 3/10/16.
//  Copyright © 2016 nus. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

