//
//  ViewController.m
//  CoreLocationDemo
//
//  Created by nus on 3/10/16.
//  Copyright © 2016 nus. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@property (weak, nonatomic) IBOutlet UILabel *lblLat;
@property (weak, nonatomic) IBOutlet UILabel *lblLong;
@property (weak, nonatomic) IBOutlet UILabel *lblAddress;

@property (weak, nonatomic) IBOutlet UILabel *lbX;
@property (weak, nonatomic) IBOutlet UILabel *lbY;
@property (weak, nonatomic) IBOutlet UILabel *lbZ;
@property (weak, nonatomic) IBOutlet UILabel *lblMagneticHeading;
@property (weak, nonatomic) IBOutlet UILabel *lblTrueHeading;

@end

@implementation ViewController{
    
    CLLocationManager *location_manager;
    CLGeocoder *geocoder;
    CLPlacemark *placemark;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    location_manager = [[CLLocationManager alloc] init];
    location_manager.delegate = self;
    
    geocoder = [[CLGeocoder alloc] init];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)onGetMyCurrentLocation:(id)sender {
    
    location_manager.desiredAccuracy = kCLLocationAccuracyBest;
    location_manager.distanceFilter = kCLDistanceFilterNone;
    [location_manager requestWhenInUseAuthorization];
    [location_manager startMonitoringSignificantLocationChanges];
    [location_manager startUpdatingLocation];
    
    location_manager.headingFilter = 0.5;
    [location_manager startUpdatingHeading];
}

- (IBAction)onStop:(id)sender {
    
    [location_manager stopUpdatingLocation];
    [location_manager stopUpdatingHeading];
}


// CLLocationManagerDelegate
-(void)locationManager:(CLLocationManager *)manager didFailWithError:(NSError *)error{
    
    UIAlertController *alert_control = [UIAlertController alertControllerWithTitle:@"Error" message:@"Failed to get location" preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *ok = [UIAlertAction actionWithTitle:@"Ok" style:UIAlertActionStyleDefault handler:nil];
    [alert_control addAction:ok];
    [self presentViewController:alert_control animated:NO completion:nil];
}

-(void)locationManager:(CLLocationManager *)manager didUpdateLocations:(NSArray<CLLocation *> *)locations{
    
    CLLocation *first_loaction = [locations lastObject];
    self.lblLat.text = [NSString stringWithFormat:@"%f",first_loaction.coordinate.latitude];
    self.lblLong.text = [NSString stringWithFormat:@"%f",first_loaction.coordinate.longitude];
    
    [geocoder reverseGeocodeLocation:first_loaction completionHandler:^(NSArray<CLPlacemark *> * _Nullable placemarks, NSError * _Nullable error) {
       
        placemark = [placemarks lastObject];
        self.lblAddress.text = [NSString stringWithFormat:@"%@ %@\n%@\n%@", placemark.subThoroughfare, placemark.thoroughfare, placemark.administrativeArea, placemark.country];
    }];
}

-(void)locationManager:(CLLocationManager *)manager didUpdateHeading:(CLHeading *)newHeading{
    
    self.lbX.text = [NSString stringWithFormat:@"%f",newHeading.x];
    self.lbY.text = [NSString stringWithFormat:@"%f",newHeading.y];
    self.lbZ.text = [NSString stringWithFormat:@"%f",newHeading.z];
    
    self.lblMagneticHeading.text = [NSString stringWithFormat:@"%f",newHeading.magneticHeading];
    self.lblTrueHeading.text = [NSString stringWithFormat:@"%f",newHeading.trueHeading];
}
@end
